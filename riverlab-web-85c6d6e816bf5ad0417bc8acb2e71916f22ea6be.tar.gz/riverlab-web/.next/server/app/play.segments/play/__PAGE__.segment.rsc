1:"$Sreact.fragment"
2:"/_next/static/chunks/0l2aaogji5g4w.js"
3:I[22016,["$2"],""]
4:I[27593,["$2"],"NavList"]
5:I[27795,["$2"],"MobileNav"]
6:"ConnectionIndicator"
7:I[49297,["$2"],"$6"]
8:I[39756,["$2"],"default"]
9:"/_next/static/chunks/0nk2n_f9lygcg.js"
a:I[58298,["$2","$9"],"default"]
:HL["/_next/static/chunks/25d59mu1zd_ky.css","style"]
f:X
f:C
10:X
10:300
10:C
14:X
14:C
18:X
18:C
15:[["children",{"s":"__PAGE__","h":49314,"d":{"r":"$L16","p":"$@17","v":"$18","s":"$10"}}]]
11:[["children",{"s":"play","h":49250,"d":{"r":"$L12","p":"$@13","v":"$14","s":"$10"},"c":"$Q15"}]]
1b:X
1b:C
1e:X
1e:C
0:{"t":{"t":{"s":"","h":49234,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/25d59mu1zd_ky.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/0l2aaogji5g4w.js","async":true}]],["$","html",null,{"lang":"en","className":"Ur3q_a_variable iaM1Ya_variable","children":["$","body",null,{"children":["$","div",null,{"className":"min-h-dvh","children":[["$","a",null,{"href":"#main","className":"sr-only z-50 rounded-md bg-accent px-3 py-2 text-canvas focus:not-sr-only focus:fixed focus:top-2 focus:left-2","children":"Skip to content"}],["$","aside",null,{"className":"fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-line bg-surface lg:flex","children":[["$","div",null,{"className":"flex h-14 items-center border-b border-line px-4","children":["$","$L3",null,{"href":"/","className":"flex items-center gap-2.5 rounded-md px-1 py-1","aria-label":"RiverLab home","children":[["$","svg",null,{"aria-hidden":true,"viewBox":"0 0 24 24","className":"size-6","children":[["$","rect",null,{"x":"1","y":"1","width":"22","height":"22","rx":"5","fill":"var(--color-accent-dim)"}],["$","path",null,{"d":"M4 15c2.5 0 2.5-3 5-3s2.5 3 5 3 2.5-3 5-3M4 10c2.5 0 2.5-3 5-3s2.5 3 5 3 2.5-3 5-3","stroke":"var(--color-accent-strong)","strokeWidth":"1.6","fill":"none","strokeLinecap":"round"}]]}],["$","span",null,{"className":"text-[15px] font-semibold tracking-tight text-fg","children":["River",["$","span",null,{"className":"text-accent","children":"Lab"}]]}]]}]}],["$","nav",null,{"aria-label":"Main","className":"flex-1 overflow-y-auto px-3 py-4","children":[["$","p",null,{"className":"label-caps mb-2 px-2.5","children":"Workspace"}],["$","$L4",null,{}]]}],["$","div",null,{"className":"border-t border-line py-3","children":["$","ul",null,{"className":"grid grid-cols-2 gap-x-3 gap-y-1 px-2.5 text-[11px] text-subtle","children":[["$","li","Available",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full bg-accent"}],"Available"]}],["$","li","Approximate model",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full ring-1 ring-warn"}],"Approximate model"]}],["$","li","In development",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full bg-info"}],"In development"]}],["$","li","Interface only",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full bg-warn"}],"Interface only"]}],["$","li","Planned",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full bg-subtle"}],"Planned"]}]]}]}]]}],["$","div",null,{"className":"flex min-h-dvh flex-col lg:pl-60","children":[["$","header",null,{"className":"sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-line bg-canvas/85 px-4 backdrop-blur lg:px-8","children":[["$","$L5",null,{}],["$","div",null,{"className":"lg:hidden","children":["$","$L3",null,{"href":"/","className":"flex items-center gap-2.5 rounded-md px-1 py-1","aria-label":"RiverLab home","children":[["$","svg",null,{"aria-hidden":true,"viewBox":"0 0 24 24","className":"size-6","children":[["$","rect",null,{"x":"1","y":"1","width":"22","height":"22","rx":"5","fill":"var(--color-accent-dim)"}],["$","path",null,{"d":"M4 15c2.5 0 2.5-3 5-3s2.5 3 5 3 2.5-3 5-3M4 10c2.5 0 2.5-3 5-3s2.5 3 5 3 2.5-3 5-3","stroke":"var(--color-accent-strong)","strokeWidth":"1.6","fill":"none","strokeLinecap":"round"}]]}],["$","span",null,{"className":"text-[15px] font-semibold tracking-tight text-fg","children":["River",["$","span",null,{"className":"text-accent","children":"Lab"}]]}]]}]}],["$","div",null,{"className":"hidden items-center gap-2 text-xs text-muted lg:flex","children":[["$","span",null,{"className":"label-caps","children":"Game"}],["$","span",null,{"className":"text-fg","children":"NL Hold'em · 6-max · Cash"}]]}],["$","div",null,{"className":"ml-auto","children":["$","$L7",null,{}]}]]}],["$","main",null,{"id":"main","className":"mx-auto w-full max-w-[1400px] flex-1 px-4 py-6 lg:px-8 lg:py-8","children":["$","$L8",null,{"parallelRouterKey":"children","error":"$a","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/0nk2n_f9lygcg.js","async":true}]],"template":"$Lb","notFound":"$Lc"}]}],"$Ld"]}]]}]}]}]]}],"p":"$@e","v":"$f","s":"$10"},"c":"$Q11"},"h":{"r":"$L19","p":"$@1a","v":"$1b","s":"$10"}},"a":"$@1c","u":"$@1d","b":"7O9XGeybZyAVPW1ziDMdG","r":"$1e"}
1f:I[37457,["$2"],"default"]
20:I[5014,["$2"],"default"]
21:"/_next/static/chunks/342r88dhr5asq.js"
22:I[38760,["$2","$21"],"PlayWorkbench"]
23:I[97367,["$2"],"OutletBoundary"]
24:"$Sreact.suspense"
26:"ViewportBoundary"
27:I[97367,["$2"],"$26"]
28:"MetadataBoundary"
29:I[97367,["$2"],"$28"]
2a:I[27201,["$2"],"IconMark"]
b:["$","$L1f",null,{}]
c:[["$","div",null,{"className":"flex flex-col items-center justify-center rounded-md border border-dashed border-line-strong px-6 py-10 text-center","children":[["$","span",null,{"className":"mb-3 text-subtle","children":["$","$L20",null,{"icon":{"name":"inbox","size":24,"node":[["polyline",{"points":"22 12 16 12 14 15 10 15 8 12 2 12","key":"o97t9d"}],["path",{"d":"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z","key":"oot6mr"}]]},"className":"size-6","aria-hidden":true}]}],["$","p",null,{"className":"text-sm font-medium text-fg","children":"Page not found"}],["$","div",null,{"className":"mt-1 max-w-md text-sm text-muted","children":"This page does not exist."}],["$","div",null,{"className":"mt-4","children":["$","$L3",null,{"href":"/","className":"text-sm text-accent hover:text-accent-strong","children":"Back to the dashboard"}]}]]}],[]]
d:["$","footer",null,{"className":"border-t border-line px-4 py-3 text-xs text-subtle lg:px-8","children":"RiverLab · Values come from the validated engine or the solver with its exploitability shown; unfinished areas are labelled as planned."}]
12:["$","$1","c",{"children":[null,["$","$L8",null,{"parallelRouterKey":"children","template":["$","$L1f",null,{}]}]]}]
16:["$","$1","c",{"children":[[["$","div",null,{"className":"mb-6 flex flex-col gap-3 border-b border-line pb-5 sm:flex-row sm:items-end sm:justify-between","children":[["$","div",null,{"children":[["$","div",null,{"className":"flex items-center gap-2.5","children":[["$","h1",null,{"className":"text-xl font-semibold tracking-tight text-fg","children":"Play"}],["$","span",null,{"className":"inline-flex items-center rounded border px-1.5 py-px text-[10px] font-medium tracking-wide uppercase bg-warn-dim text-warn border-warn/30","children":"Approximate model"}]]}],["$","p",null,{"className":"mt-1 max-w-3xl text-sm text-muted","children":"Play cash, fast-fold or sit & go games against bots at a table you configure, then review your statistics and the weaknesses found. Bots use GTOpen's preflop model (approximate) and simple postflop rules; every finding states what it is measured against."}]]}],"$undefined"]}],["$","$L22",null,{}]],[["$","script","script-0",{"src":"/_next/static/chunks/342r88dhr5asq.js","async":true}]],["$","$L23",null,{"children":["$","$24",null,{"name":"Next.MetadataOutlet","children":"$@25"}]}]]}]
19:["$","$1","h",{"children":[null,["$","$L27",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","content":"#0c0e11"}],["$","meta","3",{"name":"color-scheme","content":"dark"}]]}],["$","$L29",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$24",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Play · RiverLab"}],["$","meta","1",{"name":"description","content":"Poker theory, solving and training platform for six-max no-limit hold'em."}],["$","link","2",{"rel":"manifest","href":"/manifest.webmanifest"}],["$","link","3",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L2a","4",{}]]}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}]
1d:false
25:null
1c:null
13:"$undefined"
1a:"$undefined"
17:"$undefined"
e:"$undefined"
