globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/jmKMrlXmG_pn-OrqCz0Xj/_buildManifest.js",
    "static/jmKMrlXmG_pn-OrqCz0Xj/_ssgManifest.js",
    "static/jmKMrlXmG_pn-OrqCz0Xj/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0az8vxg2gfuhm.js",
    "static/chunks/26obk1ra3jbgz.js",
    "static/chunks/1l8i-z7w_vl9o.js",
    "static/chunks/1wg4rdrutax1u.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/academy/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/academy/[slug]/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/academy/revision/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/analytics/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/hand-analysis/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/library/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/play/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/postflop/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/preflop/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/settings/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/solver/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/trainer/page": {
      "otherChunks": [
        "static/chunks/0az8vxg2gfuhm.js",
        "static/chunks/26obk1ra3jbgz.js",
        "static/chunks/1l8i-z7w_vl9o.js",
        "static/chunks/1wg4rdrutax1u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
