:HL["/_next/static/chunks/32aamkjo2_7if.css","style"]
2:[["children",{"s":"__PAGE__","h":49314}]]
1:[["children",{"s":"/_not-found","h":49250,"c":"$Q2"}]]
0:{"b":"6HmuUGJwIq2Mu4DaZmuVG","t":{"t":{"s":"","h":49234,"c":"$Q1"}}}
