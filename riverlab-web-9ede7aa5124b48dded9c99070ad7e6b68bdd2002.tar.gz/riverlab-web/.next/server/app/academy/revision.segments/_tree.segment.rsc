:HL["/_next/static/chunks/1bzt19lkon7gp.css","style"]
:HL["/_next/static/media/GeistMono_Variable.p.2vtemngyy8z-u.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/Geist_Variable-s.p.43azbxi7zpibd.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/chunks/2a86gw0-qil9m.css","style"]
3:[["children",{"s":"__PAGE__","h":49314}]]
2:[["children",{"s":"revision","h":49250,"c":"$Q3"}]]
1:[["children",{"s":"academy","h":49250,"c":"$Q2"}]]
0:{"b":"WSA30FxSG4QUx36qMeecx","t":{"t":{"s":"","h":49234,"c":"$Q1"}}}
