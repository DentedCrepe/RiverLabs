:HL["/_next/static/chunks/1-hzhdnd_e25g.css","style"]
:HL["/_next/static/media/GeistMono_Variable.p.2vtemngyy8z-u.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/Geist_Variable-s.p.43azbxi7zpibd.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:[["children",{"s":"__PAGE__","h":49314}]]
1:[["children",{"s":"academy","h":49250,"c":"$Q2"}]]
0:{"b":"qqPtwlM188nWJ79MKsEWH","t":{"t":{"s":"","h":49234,"c":"$Q1"}}}
