:HL["/_next/static/chunks/2m4jaulaoxraw.css","style"]
2:[["children",{"s":"__PAGE__","h":49314}]]
1:[["children",{"s":"/_not-found","h":49250,"c":"$Q2"}]]
0:{"b":"55JCGjDl-K4Pq_iLa7F5P","t":{"t":{"s":"","h":49234,"c":"$Q1"}}}
