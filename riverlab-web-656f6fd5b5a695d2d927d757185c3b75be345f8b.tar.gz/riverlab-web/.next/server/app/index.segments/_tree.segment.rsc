:HL["/_next/static/chunks/2kxzqccsz59id.css","style"]
:HL["/_next/static/media/GeistMono_Variable.p.2vtemngyy8z-u.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/Geist_Variable-s.p.43azbxi7zpibd.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
1:[["children",{"s":"__PAGE__","h":49282}]]
0:{"b":"aI9ieGzMnxubtbUHr2XG_","t":{"t":{"s":"","h":49170,"c":"$Q1"}}}
