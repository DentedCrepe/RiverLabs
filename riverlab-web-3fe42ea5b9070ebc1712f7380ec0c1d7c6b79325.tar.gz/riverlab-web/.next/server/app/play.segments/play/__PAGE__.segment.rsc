1:"$Sreact.fragment"
2:"/_next/static/chunks/1td9e1ucu4bzj.js"
3:I[22016,["$2"],""]
4:I[27593,["$2"],"NavList"]
5:I[27795,["$2"],"MobileNav"]
6:"ConnectionIndicator"
7:I[49297,["$2"],"$6"]
8:I[39756,["$2"],"default"]
9:"/_next/static/chunks/2dz5_9wiza6cu.js"
a:I[58298,["$2","$9"],"default"]
b:I[37457,["$2"],"default"]
:HL["/_next/static/chunks/3wvgp3uuyv_n9.css","style"]
12:X
12:C
13:X
13:300
13:C
17:X
17:C
1b:X
1b:C
18:[["children",{"s":"__PAGE__","h":49314,"d":{"r":"$L19","p":"$@1a","v":"$1b","s":"$13"}}]]
14:[["children",{"s":"play","h":49250,"d":{"r":"$L15","p":"$@16","v":"$17","s":"$13"},"c":"$Q18"}]]
1e:X
1e:C
21:X
21:C
0:{"t":{"t":{"s":"","h":49234,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/3wvgp3uuyv_n9.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/1td9e1ucu4bzj.js","async":true}]],["$","html",null,{"lang":"en","className":"Ur3q_a_variable iaM1Ya_variable","children":["$","body",null,{"children":["$","div",null,{"className":"min-h-dvh","children":[["$","a",null,{"href":"#main","className":"sr-only z-50 rounded-md bg-accent px-3 py-2 text-canvas focus:not-sr-only focus:fixed focus:top-2 focus:left-2","children":"Skip to content"}],["$","aside",null,{"className":"fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-line bg-surface lg:flex","children":[["$","div",null,{"className":"flex h-14 items-center border-b border-line px-4","children":["$","$L3",null,{"href":"/","className":"flex items-center gap-2.5 rounded-md px-1 py-1","aria-label":"RiverLab home","children":[["$","svg",null,{"aria-hidden":true,"viewBox":"0 0 24 24","className":"size-6","children":[["$","rect",null,{"x":"1","y":"1","width":"22","height":"22","rx":"5","fill":"var(--color-accent-dim)"}],["$","path",null,{"d":"M4 15c2.5 0 2.5-3 5-3s2.5 3 5 3 2.5-3 5-3M4 10c2.5 0 2.5-3 5-3s2.5 3 5 3 2.5-3 5-3","stroke":"var(--color-accent-strong)","strokeWidth":"1.6","fill":"none","strokeLinecap":"round"}]]}],["$","span",null,{"className":"text-[15px] font-semibold tracking-tight text-fg","children":["River",["$","span",null,{"className":"text-accent","children":"Lab"}]]}]]}]}],["$","nav",null,{"aria-label":"Main","className":"flex-1 overflow-y-auto px-3 py-4","children":[["$","p",null,{"className":"label-caps mb-2 px-2.5","children":"Workspace"}],["$","$L4",null,{}]]}],["$","div",null,{"className":"border-t border-line py-3","children":["$","ul",null,{"className":"grid grid-cols-2 gap-x-3 gap-y-1 px-2.5 text-[11px] text-subtle","children":[["$","li","Available",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full bg-accent"}],"Available"]}],["$","li","In development",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full bg-info"}],"In development"]}],["$","li","Interface only",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full bg-warn"}],"Interface only"]}],["$","li","Planned",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full bg-subtle"}],"Planned"]}]]}]}]]}],["$","div",null,{"className":"flex min-h-dvh flex-col lg:pl-60","children":[["$","header",null,{"className":"sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-line bg-canvas/85 px-4 backdrop-blur lg:px-8","children":[["$","$L5",null,{}],["$","div",null,{"className":"lg:hidden","children":["$","$L3",null,{"href":"/","className":"flex items-center gap-2.5 rounded-md px-1 py-1","aria-label":"RiverLab home","children":[["$","svg",null,{"aria-hidden":true,"viewBox":"0 0 24 24","className":"size-6","children":[["$","rect",null,{"x":"1","y":"1","width":"22","height":"22","rx":"5","fill":"var(--color-accent-dim)"}],["$","path",null,{"d":"M4 15c2.5 0 2.5-3 5-3s2.5 3 5 3 2.5-3 5-3M4 10c2.5 0 2.5-3 5-3s2.5 3 5 3 2.5-3 5-3","stroke":"var(--color-accent-strong)","strokeWidth":"1.6","fill":"none","strokeLinecap":"round"}]]}],["$","span",null,{"className":"text-[15px] font-semibold tracking-tight text-fg","children":["River",["$","span",null,{"className":"text-accent","children":"Lab"}]]}]]}]}],["$","div",null,{"className":"hidden items-center gap-2 text-xs text-muted lg:flex","children":[["$","span",null,{"className":"label-caps","children":"Game"}],["$","span",null,{"className":"text-fg","children":"NL Hold'em · 6-max · Cash"}]]}],["$","div",null,{"className":"ml-auto","children":["$","$L7",null,{}]}]]}],["$","main",null,{"id":"main","className":"mx-auto w-full max-w-[1400px] flex-1 px-4 py-6 lg:px-8 lg:py-8","children":["$","$L8",null,{"parallelRouterKey":"children","error":"$a","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/2dz5_9wiza6cu.js","async":true}]],"template":["$","$Lb",null,{}],"notFound":[["$","div",null,{"className":"flex flex-col items-center justify-center rounded-md border border-dashed border-line-strong px-6 py-10 text-center","children":["$Lc","$Ld","$Le","$Lf"]}],[]]}]}],"$L10"]}]]}]}]}]]}],"p":"$@11","v":"$12","s":"$13"},"c":"$Q14"},"h":{"r":"$L1c","p":"$@1d","v":"$1e","s":"$13"}},"a":"$@1f","u":"$@20","b":"wRBytSo55HIYf7H7DgsPq","r":"$21"}
22:I[5014,["$2"],"default"]
23:"/_next/static/chunks/1-tze84f56_1s.js"
24:I[38760,["$2","$23"],"PlayWorkbench"]
25:I[97367,["$2"],"OutletBoundary"]
26:"$Sreact.suspense"
28:"ViewportBoundary"
29:I[97367,["$2"],"$28"]
2a:"MetadataBoundary"
2b:I[97367,["$2"],"$2a"]
2c:I[27201,["$2"],"IconMark"]
c:["$","span",null,{"className":"mb-3 text-subtle","children":["$","$L22",null,{"icon":{"name":"inbox","size":24,"node":[["polyline",{"points":"22 12 16 12 14 15 10 15 8 12 2 12","key":"o97t9d"}],["path",{"d":"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z","key":"oot6mr"}]]},"className":"size-6","aria-hidden":true}]}]
d:["$","p",null,{"className":"text-sm font-medium text-fg","children":"Page not found"}]
e:["$","div",null,{"className":"mt-1 max-w-md text-sm text-muted","children":"This page does not exist."}]
f:["$","div",null,{"className":"mt-4","children":["$","$L3",null,{"href":"/","className":"text-sm text-accent hover:text-accent-strong","children":"Back to the dashboard"}]}]
10:["$","footer",null,{"className":"border-t border-line px-4 py-3 text-xs text-subtle lg:px-8","children":"RiverLab · Values come from the validated engine or the solver with its exploitability shown; unfinished areas are labelled as planned."}]
15:["$","$1","c",{"children":[null,["$","$L8",null,{"parallelRouterKey":"children","template":["$","$Lb",null,{}]}]]}]
19:["$","$1","c",{"children":[[["$","div",null,{"className":"mb-6 flex flex-col gap-3 border-b border-line pb-5 sm:flex-row sm:items-end sm:justify-between","children":[["$","div",null,{"children":[["$","div",null,{"className":"flex items-center gap-2.5","children":[["$","h1",null,{"className":"text-xl font-semibold tracking-tight text-fg","children":"Play"}],["$","span",null,{"className":"inline-flex items-center rounded border px-1.5 py-px text-[10px] font-medium tracking-wide uppercase bg-warn-dim text-warn border-warn/30","children":"Approximate model"}]]}],["$","p",null,{"className":"mt-1 max-w-3xl text-sm text-muted","children":"Play cash, fast-fold or sit & go games against bots at a table you configure, then review your statistics and the weaknesses found. Bots use GTOpen's preflop model (approximate) and simple postflop rules; every finding states what it is measured against."}]]}],"$undefined"]}],["$","$L24",null,{}]],[["$","script","script-0",{"src":"/_next/static/chunks/1-tze84f56_1s.js","async":true}]],["$","$L25",null,{"children":["$","$26",null,{"name":"Next.MetadataOutlet","children":"$@27"}]}]]}]
1c:["$","$1","h",{"children":[null,["$","$L29",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","content":"#0c0e11"}],["$","meta","3",{"name":"color-scheme","content":"dark"}]]}],["$","$L2b",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$26",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Play · RiverLab"}],["$","meta","1",{"name":"description","content":"Poker theory, solving and training platform for six-max no-limit hold'em."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L2c","3",{}]]}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}]
20:false
27:null
1f:null
16:"$undefined"
1d:"$undefined"
1a:"$undefined"
11:"$undefined"
