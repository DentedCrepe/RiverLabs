globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/wRBytSo55HIYf7H7DgsPq/_buildManifest.js",
    "static/wRBytSo55HIYf7H7DgsPq/_ssgManifest.js",
    "static/wRBytSo55HIYf7H7DgsPq/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/3mwm0pfu8c8me.js",
    "static/chunks/01t2i9pe5vz2-.js",
    "static/chunks/2fuxlcqleg9x-.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/01t2i9pe5vz2-.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/01t2i9pe5vz2-.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/01t2i9pe5vz2-.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/analytics/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/01t2i9pe5vz2-.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/hand-analysis/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/01t2i9pe5vz2-.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/library/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/01t2i9pe5vz2-.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/play/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/01t2i9pe5vz2-.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/postflop/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/01t2i9pe5vz2-.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/preflop/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/01t2i9pe5vz2-.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/settings/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/01t2i9pe5vz2-.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/solver/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/01t2i9pe5vz2-.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/trainer/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/01t2i9pe5vz2-.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
