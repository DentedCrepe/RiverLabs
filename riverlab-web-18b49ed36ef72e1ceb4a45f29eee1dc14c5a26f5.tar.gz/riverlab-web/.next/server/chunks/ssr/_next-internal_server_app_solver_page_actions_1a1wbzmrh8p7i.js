module.exports=[1751,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_solver_page_actions_1a1wbzmrh8p7i.js.map