module.exports=[27417,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_hand-analysis_page_actions_1etkygp4az6vy.js.map