module.exports=[97265,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_academy_revision_page_actions_1nw6d1fuynxtw.js.map