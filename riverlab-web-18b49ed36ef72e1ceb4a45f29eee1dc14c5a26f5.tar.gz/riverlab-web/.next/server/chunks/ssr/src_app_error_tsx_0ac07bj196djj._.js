module.exports=[23953,a=>{"use strict";var b=a.i(87924),c=a.i(96438),d=a.i(12503);a.s(["default",0,function({error:a,reset:e}){return(0,b.jsx)(d.D,{title:"This page failed to render",message:a.message||"Unexpected error",action:(0,b.jsx)(c.f,{size:"sm",onClick:e,children:"Try again"})})}])}];

//# sourceMappingURL=src_app_error_tsx_0ac07bj196djj._.js.map