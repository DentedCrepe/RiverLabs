module.exports=[98060,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_postflop_page_actions_0npb8nftdl6px.js.map