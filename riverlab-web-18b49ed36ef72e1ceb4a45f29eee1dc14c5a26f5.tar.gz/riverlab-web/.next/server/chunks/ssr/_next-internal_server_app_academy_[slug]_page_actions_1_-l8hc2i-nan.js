module.exports=[30814,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_academy_%5Bslug%5D_page_actions_1_-l8hc2i-nan.js.map