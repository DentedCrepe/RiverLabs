var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/backend/[...path]/route.js")
R.c("server/chunks/[externals]__0bwf06g0pqv3h._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_1gag47ln3lpyo._.js")
R.c("server/chunks/_next-internal_server_app_api_backend_[___path]_route_actions_0xgsz5tuf90mb.js")
R.m(6137)
module.exports=R.m(6137).exports
