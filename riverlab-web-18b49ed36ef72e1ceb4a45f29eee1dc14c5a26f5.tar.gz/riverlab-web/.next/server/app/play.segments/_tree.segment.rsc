:HL["/_next/static/chunks/39hn2vqpu25d-.css","style"]
:HL["/_next/static/media/GeistMono_Variable.p.2vtemngyy8z-u.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/Geist_Variable-s.p.43azbxi7zpibd.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:[["children",{"s":"__PAGE__","h":49314}]]
1:[["children",{"s":"play","h":49250,"c":"$Q2"}]]
0:{"b":"-OuyuVyBNhp-_QrFMgUV6","t":{"t":{"s":"","h":49234,"c":"$Q1"}}}
