module.exports=[27129,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_academy_review_page_actions_17zuqchsuli6f.js.map