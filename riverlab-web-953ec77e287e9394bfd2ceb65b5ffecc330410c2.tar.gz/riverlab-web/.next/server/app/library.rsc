#1:"$Sreact.fragment"
2:"/_next/static/chunks/183x_hxli59v-.js"
3:"/_next/static/chunks/3w2js2l453wpv.js"
4:I[22016,["$2","$3"],""]
5:I[27593,["$2","$3"],"NavList"]
6:I[27795,["$2","$3"],"MobileNav"]
7:I[60870,["$2","$3"],"GuestToggle"]
8:"ConnectionIndicator"
9:I[49297,["$2","$3"],"$8"]
a:I[60870,["$2","$3"],"GuestBanner"]
16:I[68027,["$2","$3"],"default",1]
:HL["/_next/static/chunks/252baodolnk8d.css","style"]
:HL["/_next/static/media/GeistMono_Variable.p.2vtemngyy8z-u.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/Geist_Variable-s.p.43azbxi7zpibd.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
d:X
10:X
13:X
11:[["children",{"s":"__PAGE__","h":514,"d":{"r":"$L12","p":true,"v":"$13"}}]]
e:[["children",{"s":"library","h":514,"d":{"r":"$Lf","p":true,"v":"$10"},"c":"$Q11"}]]
15:X
18:X
19:X
0:{"P":null,"c":["","library"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/252baodolnk8d.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/183x_hxli59v-.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/3w2js2l453wpv.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"Ur3q_a_variable iaM1Ya_variable","children":["$","body",null,{"children":["$","div",null,{"className":"min-h-dvh","children":[["$","a",null,{"href":"#main","className":"sr-only z-50 rounded-md bg-accent px-3 py-2 text-canvas focus:not-sr-only focus:fixed focus:top-2 focus:left-2","children":"Skip to content"}],["$","aside",null,{"className":"fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-line bg-surface lg:flex","children":[["$","div",null,{"className":"flex h-14 items-center border-b border-line px-4","children":["$","$L4",null,{"href":"/","className":"flex items-center gap-2.5 rounded-md px-1 py-1","aria-label":"RiverLab home","children":[["$","svg",null,{"aria-hidden":true,"viewBox":"0 0 24 24","className":"size-6","children":[["$","rect",null,{"x":"1","y":"1","width":"22","height":"22","rx":"5","fill":"var(--color-accent-dim)"}],["$","path",null,{"d":"M4 15c2.5 0 2.5-3 5-3s2.5 3 5 3 2.5-3 5-3M4 10c2.5 0 2.5-3 5-3s2.5 3 5 3 2.5-3 5-3","stroke":"var(--color-accent-strong)","strokeWidth":"1.6","fill":"none","strokeLinecap":"round"}]]}],["$","span",null,{"className":"text-[15px] font-semibold tracking-tight text-fg","children":["River",["$","span",null,{"className":"text-accent","children":"Lab"}]]}]]}]}],["$","nav",null,{"aria-label":"Main","className":"flex-1 overflow-y-auto px-3 py-4","children":[["$","p",null,{"className":"label-caps mb-2 px-2.5","children":"Workspace"}],["$","$L5",null,{}]]}],["$","div",null,{"className":"border-t border-line py-3","children":["$","ul",null,{"className":"grid grid-cols-2 gap-x-3 gap-y-1 px-2.5 text-[11px] text-subtle","children":[["$","li","Available",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full bg-accent"}],"Available"]}],["$","li","Approximate model",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full ring-1 ring-warn"}],"Approximate model"]}],["$","li","In development",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full bg-info"}],"In development"]}],["$","li","Interface only",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full bg-warn"}],"Interface only"]}],["$","li","Planned",{"className":"flex items-center gap-1.5","children":[["$","span",null,{"aria-hidden":true,"className":"size-1.5 rounded-full bg-subtle"}],"Planned"]}]]}]}]]}],["$","div",null,{"className":"flex min-h-dvh flex-col lg:pl-60","children":[["$","header",null,{"className":"sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-line bg-canvas/85 px-4 backdrop-blur lg:px-8","children":[["$","$L6",null,{}],["$","div",null,{"className":"lg:hidden","children":["$","$L4",null,{"href":"/","className":"flex items-center gap-2.5 rounded-md px-1 py-1","aria-label":"RiverLab home","children":[["$","svg",null,{"aria-hidden":true,"viewBox":"0 0 24 24","className":"size-6","children":[["$","rect",null,{"x":"1","y":"1","width":"22","height":"22","rx":"5","fill":"var(--color-accent-dim)"}],["$","path",null,{"d":"M4 15c2.5 0 2.5-3 5-3s2.5 3 5 3 2.5-3 5-3M4 10c2.5 0 2.5-3 5-3s2.5 3 5 3 2.5-3 5-3","stroke":"var(--color-accent-strong)","strokeWidth":"1.6","fill":"none","strokeLinecap":"round"}]]}],["$","span",null,{"className":"text-[15px] font-semibold tracking-tight text-fg","children":["River",["$","span",null,{"className":"text-accent","children":"Lab"}]]}]]}]}],["$","div",null,{"className":"hidden items-center gap-2 text-xs text-muted lg:flex","children":[["$","span",null,{"className":"label-caps","children":"Game"}],["$","span",null,{"className":"text-fg","children":"NL Hold'em · 6-max · Cash"}]]}],["$","div",null,{"className":"ml-auto flex items-center gap-2","children":[["$","$L7",null,{}],["$","$L9",null,{}]]}]]}],["$","$La",null,{}],["$","main",null,{"id":"main","className":"mx-auto w-full max-w-[1400px] flex-1 px-4 py-6 lg:px-8 lg:py-8","children":"$Lb"}],"$Lc"]}]]}]}]}]]}],"p":true,"v":"$d"},"c":"$Qe"},"h":{"r":"$L14","p":true,"v":"$15"}},"m":"$undefined","G":["$16",["$L17"]],"S":true,"r":"$18","s":"$19","a":"$@1a","l":"$undefined","p":"$undefined","d":"$undefined","b":"HGi0ZA94c0MVTVrMWp1Pb","u":"$@1b"}
1c:I[39756,["$2","$3"],"default"]
1d:"/_next/static/chunks/35wji2xnw4zzk.js"
1e:I[58298,["$2","$3","$1d"],"default"]
1f:I[37457,["$2","$3"],"default"]
20:I[5014,["$2","$3"],"default"]
21:"/_next/static/chunks/0_avb2hq4lbt-.js"
22:"/_next/static/chunks/41pi-y_n66ew1.js"
23:I[49174,["$2","$3","$21","$22"],"Library"]
24:I[97367,["$2","$3"],"OutletBoundary"]
25:"$Sreact.suspense"
27:"ViewportBoundary"
28:I[97367,["$2","$3"],"$27"]
2a:"MetadataBoundary"
2b:I[97367,["$2","$3"],"$2a"]
b:["$","$L1c",null,{"parallelRouterKey":"children","error":"$1e","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/35wji2xnw4zzk.js","async":true,"nonce":"$undefined"}]],"template":["$","$L1f",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"flex flex-col items-center justify-center rounded-md border border-dashed border-line-strong px-6 py-10 text-center","children":[["$","span",null,{"className":"mb-3 text-subtle","children":["$","$L20",null,{"ref":"$undefined","icon":{"name":"inbox","size":24,"node":[["polyline",{"points":"22 12 16 12 14 15 10 15 8 12 2 12","key":"o97t9d"}],["path",{"d":"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z","key":"oot6mr"}]]},"className":"size-6","aria-hidden":true}]}],["$","p",null,{"className":"text-sm font-medium text-fg","children":"Page not found"}],["$","div",null,{"className":"mt-1 max-w-md text-sm text-muted","children":"This page does not exist."}],["$","div",null,{"className":"mt-4","children":["$","$L4",null,{"href":"/","className":"text-sm text-accent hover:text-accent-strong","children":"Back to the dashboard"}]}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]
c:["$","footer",null,{"className":"border-t border-line px-4 py-3 text-xs text-subtle lg:px-8","children":"RiverLab · Values come from the validated engine or the solver with its exploitability shown; unfinished areas are labelled as planned."}]
f:["$","$1","c",{"children":[null,["$","$L1c",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L1f",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
12:["$","$1","c",{"children":[[["$","div",null,{"className":"mb-6 flex flex-col gap-3 border-b border-line pb-5 sm:flex-row sm:items-end sm:justify-between","children":[["$","div",null,{"children":[["$","div",null,{"className":"flex items-center gap-2.5","children":[["$","h1",null,{"className":"text-xl font-semibold tracking-tight text-fg","children":"Solution Library"}],["$","span",null,{"className":"inline-flex items-center rounded border px-1.5 py-px text-[10px] font-medium tracking-wide uppercase bg-accent-dim text-accent-strong border-accent/30","children":"Available"}]]}],["$","p",null,{"className":"mt-1 max-w-3xl text-sm text-muted","children":"Every saved solver result with its full configuration, engine and solver versions, and its exploitability (postflop) or model gap (preflop, an approximate model unless marked validated)."}]]}],"$undefined"]}],["$","section",null,{"className":"rounded-[var(--radius-card)] border border-line bg-surface","children":["$","div",null,{"className":"p-4","children":["$","$L23",null,{}]}]}]],[["$","script","script-0",{"src":"/_next/static/chunks/0_avb2hq4lbt-.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/41pi-y_n66ew1.js","async":true,"nonce":"$undefined"}]],["$","$L24",null,{"children":["$","$25",null,{"name":"Next.MetadataOutlet","children":"$@26"}]}]]}]
14:["$","$1","h",{"children":[null,["$","$L28",null,{"children":"$L29"}],["$","$L2b",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$25",null,{"name":"Next.Metadata","children":"$L2c"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}]
17:["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/252baodolnk8d.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]
10:C
19:300
29:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","content":"#0c0e11"}],["$","meta","3",{"name":"color-scheme","content":"dark"}]]
2d:I[27201,["$2","$3"],"IconMark"]
26:null
2c:[["$","title","0",{"children":"Solution Library · RiverLab"}],["$","meta","1",{"name":"description","content":"Poker theory, solving and training platform for six-max no-limit hold'em."}],["$","link","2",{"rel":"manifest","href":"/manifest.webmanifest","crossOrigin":"$undefined"}],["$","link","3",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L2d","4",{}]]
19:C
15:C
18:C
13:C
d:C
1b:false
1a:null
