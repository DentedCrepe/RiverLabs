:HL["/_next/static/chunks/252baodolnk8d.css","style"]
:HL["/_next/static/media/GeistMono_Variable.p.2vtemngyy8z-u.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/Geist_Variable-s.p.43azbxi7zpibd.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:[["children",{"s":"__PAGE__","h":49314}]]
1:[["children",{"s":"postflop","h":49218,"c":"$Q2"}]]
0:{"b":"HGi0ZA94c0MVTVrMWp1Pb","t":{"t":{"s":"","h":49170,"c":"$Q1"}}}
